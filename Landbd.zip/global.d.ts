declare module "*.css";
declare module "bootstrap/dist/js/bootstrap.bundle.min.js";
